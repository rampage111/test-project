#include <iostream>

namespace fractions
{
	class simpleFract
	{
		int _nom;
		int _denom;
	public:
		simpleFract(int nom = 1, int denom = 2) :_nom{ nom }, _denom{ denom }{}
		void setNom(int x) { _nom = x; }
		void setDenom(int y) { _denom = y; }
		float solve()
		{
			return (_denom) ? (float)_nom / _denom : -0.123;
		}

		void print()
		{
			std::cout << _nom << "/" << _denom << "\n";
		}
	};
}