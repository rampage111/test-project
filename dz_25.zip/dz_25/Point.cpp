#include <iostream>

namespace points
{
	class point3d
	{
		int _x;
		int _y;
		int _z;
	public:
		point3d(int x = 1, int y = 1, int z = 1) :_x{ x }, _y{ y }, _z{ z }{}
		void setX(int x) { _x = x; }
		void setY(int y) { _y = y; }
		void setZ(int z) { _z = z; }

		void print()
		{
			std::cout << "(" << _x << ", " << _y << ", " << _z << ")\n";
		}
	};
}