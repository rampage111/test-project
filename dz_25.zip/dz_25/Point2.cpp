#include <iostream>

namespace points
{
	class point2d
	{
		int _x;
		int _y;
	public:
		point2d(int x = 1, int y = 1) :_x{ x }, _y{ y }{}
		void setX(int x) { _x = x; }
		void setY(int y) { _y = y; }


		void print()
		{
			std::cout << "(" << _x << ", " << _y << ")\n";
		}
	};
}