﻿#include <iostream>
#include<string.h>
#include "Point.cpp"
#include "Point2.cpp"
#include "Fraction.cpp"


int main()
{
	points::point2d zero(0, 0);
	std::cout << "Using namespace \"points\":\n";
	zero.print();

	points::point3d cube4(4, 4, 4);
	std::cout << "Using namespace \"points\" in other file:\n";
	cube4.print();

	fractions::simpleFract t(3, 4);
	std::cout << "Using namespace \"fractions\":\n";
	t.print();
	std::cout << "will be " << t.solve() << "\n";


	return 0;
}

